//
//  listaViewController.h
//  UserLoginAndRegistration
//
//  Created by inv obr on 3/09/15.
//  Copyright (c) 2015 inv obr. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface listaViewController : UIViewController
{
    
    
    IBOutlet UIAlertView *alerta;
}



-(IBAction)button:(id)sender;

@end
