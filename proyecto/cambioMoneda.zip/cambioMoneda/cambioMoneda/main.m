//
//  main.m
//  cambioMoneda
//
//  Created by inv obr on 14/09/15.
//  Copyright (c) 2015 inv obr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
